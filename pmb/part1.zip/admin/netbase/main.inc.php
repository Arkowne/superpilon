<?php
// +-------------------------------------------------+
// � 2002-2004 PMB Services / www.sigb.net pmb@sigb.net et contributeurs (voir www.sigb.net)
// +-------------------------------------------------+
// $Id: main.inc.php,v 1.11.6.1 2021/02/09 18:06:36 dgoron Exp $

if (stristr($_SERVER['REQUEST_URI'], ".inc.php")) die("no access");

?>

<br /><br />
<div class="row">
    <iframe name="ititre" frameborder="0" scrolling="auto" width="600" height="700" src="./admin/netbase/clean.php">
</div>