<?php
// +-------------------------------------------------+
// � 2002-2004 PMB Services / www.sigb.net pmb@sigb.net et contributeurs (voir www.sigb.net)
// +-------------------------------------------------+
// $Id: import.inc.php,v 1.6 2008/06/27 16:01:42 jokester Exp $

if (stristr($_SERVER['REQUEST_URI'], ".inc.php")) die("no access");

?>
<div>
<iframe name="ieimport" frameborder="0" scrolling="yes" width="100%" height="500" src="./admin/convert/import.php">
</div>
<noframes>
</noframes>