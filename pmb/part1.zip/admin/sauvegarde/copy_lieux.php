<?php
// +-------------------------------------------------+
// � 2002-2004 PMB Services / www.sigb.net pmb@sigb.net et contributeurs (voir www.sigb.net)
// +-------------------------------------------------+
// $Id: copy_lieux.php,v 1.10 2017/10/23 10:13:00 ngantier Exp $

//if (stristr($_SERVER['REQUEST_URI'], ".inc.php")) die("no access");

//Copie vers les lieux

$base_path="../..";
$base_auth="SAUV_AUTH|ADMINISTRATION_AUTH";
$base_title="\$msg[sauv_misc_transfert_running]";
require($base_path."/includes/init.inc.php");

require("lib/api.inc.php");

//R�cup�ration du lieu
$requete="select sauv_lieu_nom,sauv_lieu_url, sauv_lieu_protocol, sauv_lieu_login, sauv_lieu_password, sauv_lieu_host from sauv_lieux where sauv_lieu_id=".$sauv_lieu_id;
$resultat=@pmb_mysql_query($requete);

$res=pmb_mysql_fetch_object($resultat);

//message
print "<div id=\"contenu-frame\">\n";
echo "<h1>".sprintf($msg["sauv_misc_warning_transfert"],$res->sauv_lieu_nom)."</h1>";
echo "<br /><br /><a href=\"\" onClick=\"self.close();\">".$msg["sauv_misc_close_window"]."</a>";
flush();
$tfilecopy=explode("/",$filename);
$filecopy=$tfilecopy[count($tfilecopy)-1];

switch ($res->sauv_lieu_protocol) {
	//Si protocol = file
	case "file" :
		if (!copy($filename,$res->sauv_lieu_url."/".$filecopy)) {
			abort("Copy : ".$res->sauv_lieu_nom." : Failed",$logid);	
		} else {
			write_log("Copy : ".$res->sauv_lieu_nom." : Succeed",$logid);
		}
	break;
	//Si protocol = ftp
	case "ftp" :
		$msg_="";
		//Connexion + passage dans le r�pertoire concern�
		$conn_id=connectFtp($res->sauv_lieu_host, $res->sauv_lieu_login, $res->sauv_lieu_password, $res->sauv_lieu_url, $msg_);
		if ($conn_id=="") {
			abort_copy("Copy : ".$res->sauv_lieu_nom." : Failed : ".$msg_,$logid);
		} else {
			//Transfert
			if (!ftp_put($conn_id, $filecopy, $filename, FTP_BINARY)) {
				abort_copy("Copy : ".$res->sauv_lieu_nom." : Failed",$logid);
			} else {
				write_log("Copy : ".$res->sauv_lieu_nom." : Succeed",$logid);
			}
		}
	break;
}
echo "<script>self.close();</script>";
echo "</div>";
?>